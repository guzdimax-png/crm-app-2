import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { DragDropContext } from "@hello-pangea/dnd";
import { STAGES } from "@/lib/stageConfig";
import PipelineColumn from "@/components/pipeline/PipelineColumn";

export default function Pipeline() {
  const queryClient = useQueryClient();

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list("-created_date", 500),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Customer.update(id, data),
    onMutate: async ({ id, data }) => {
      await queryClient.cancelQueries({ queryKey: ["customers"] });
      const prev = queryClient.getQueryData(["customers"]);
      queryClient.setQueryData(["customers"], (old) =>
        old.map((c) => (c.id === id ? { ...c, ...data } : c))
      );
      return { prev };
    },
    onError: (err, vars, ctx) => {
      queryClient.setQueryData(["customers"], ctx.prev);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
    },
  });

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const { draggableId, destination } = result;
    const newStage = destination.droppableId;
    const customer = customers.find((c) => c.id === draggableId);
    if (!customer || customer.stage === newStage) return;

    updateMutation.mutate({ id: draggableId, data: { stage: newStage } });

    // Log stage change activity
    base44.entities.Activity.create({
      customer_id: draggableId,
      type: "stage_change",
      content: `שלב שונה`,
      old_stage: customer.stage,
      new_stage: newStage,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Pipeline</h1>
        <p className="text-muted-foreground text-sm">גרור לקוחות בין השלבים</p>
      </div>
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="flex gap-3 overflow-x-auto pb-4" style={{ direction: "ltr" }}>
          {STAGES.map((stage, idx) => (
            <PipelineColumn
              key={stage.id}
              stage={stage}
              index={idx}
              customers={customers.filter((c) => c.stage === stage.id)}
            />
          ))}
        </div>
      </DragDropContext>
    </div>
  );
}