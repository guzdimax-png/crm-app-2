import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, ChevronLeft, Calendar as CalendarIcon, Wrench, Users } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths, isToday, startOfWeek, endOfWeek } from "date-fns";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

const DAYS_HE = ["א׳", "ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳"];

export default function CalendarPage() {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const { data: customers = [] } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list("-created_date", 500),
  });

  const events = useMemo(() => {
    const evts = [];
    customers.forEach((c) => {
      if (c.meeting_date) {
        evts.push({ date: new Date(c.meeting_date), type: "meeting", customer: c });
      }
      if (c.installation_date) {
        evts.push({ date: new Date(c.installation_date), type: "installation", customer: c });
      }
    });
    return evts;
  }, [customers]);

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calStart = startOfWeek(monthStart, { weekStartsOn: 0 });
  const calEnd = endOfWeek(monthEnd, { weekStartsOn: 0 });
  const days = eachDayOfInterval({ start: calStart, end: calEnd });

  const getEventsForDay = (day) => events.filter((e) => isSameDay(e.date, day));

  const todayEvents = events
    .filter((e) => isSameDay(e.date, new Date()))
    .sort((a, b) => a.date - b.date);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">יומן</h1>
        <p className="text-muted-foreground text-sm">פגישות והתקנות</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-base">{format(currentMonth, "MMMM yyyy")}</CardTitle>
            <div className="flex gap-1">
              <Button size="icon" variant="ghost" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
                <ChevronRight className="w-4 h-4" />
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setCurrentMonth(new Date())}>
                היום
              </Button>
              <Button size="icon" variant="ghost" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-px">
              {DAYS_HE.map((d) => (
                <div key={d} className="text-center text-xs font-medium text-muted-foreground py-2">
                  {d}
                </div>
              ))}
              {days.map((day) => {
                const dayEvents = getEventsForDay(day);
                const inMonth = day.getMonth() === currentMonth.getMonth();
                return (
                  <div
                    key={day.toISOString()}
                    className={cn(
                      "min-h-[80px] p-1.5 border border-border/50 rounded-lg",
                      !inMonth && "opacity-30",
                      isToday(day) && "bg-primary/5 border-primary/30"
                    )}
                  >
                    <span className={cn(
                      "text-xs font-medium",
                      isToday(day) && "text-primary font-bold"
                    )}>
                      {format(day, "d")}
                    </span>
                    <div className="space-y-0.5 mt-1">
                      {dayEvents.slice(0, 2).map((evt, i) => (
                        <Link
                          key={i}
                          to={`/customers/${evt.customer.id}`}
                          className={cn(
                            "block text-[10px] px-1 py-0.5 rounded truncate",
                            evt.type === "meeting" ? "bg-purple-100 text-purple-700" : "bg-teal-100 text-teal-700"
                          )}
                        >
                          {evt.customer.full_name}
                        </Link>
                      ))}
                      {dayEvents.length > 2 && (
                        <span className="text-[10px] text-muted-foreground">+{dayEvents.length - 2}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">אירועים להיום</CardTitle>
          </CardHeader>
          <CardContent>
            {todayEvents.length > 0 ? (
              <div className="space-y-3">
                {todayEvents.map((evt, i) => (
                  <Link
                    key={i}
                    to={`/customers/${evt.customer.id}`}
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-secondary transition-colors"
                  >
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center",
                      evt.type === "meeting" ? "bg-purple-100 text-purple-600" : "bg-teal-100 text-teal-600"
                    )}>
                      {evt.type === "meeting" ? <Users className="w-4 h-4" /> : <Wrench className="w-4 h-4" />}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{evt.customer.full_name}</p>
                      <p className="text-xs text-muted-foreground">
                        {evt.type === "meeting" ? "פגישה" : "התקנה"} • {format(evt.date, "HH:mm")}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center py-8 text-muted-foreground">
                <CalendarIcon className="w-8 h-8 opacity-30 mb-2" />
                <p className="text-sm">אין אירועים להיום</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}