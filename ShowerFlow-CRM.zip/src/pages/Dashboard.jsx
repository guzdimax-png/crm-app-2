import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Users, TrendingUp, Wrench, CheckCircle2, AlertTriangle, DollarSign } from "lucide-react";
import StatCard from "@/components/dashboard/StatCard";
import StageChart from "@/components/dashboard/StageChart";
import RecentCustomers from "@/components/dashboard/RecentCustomers";

export default function Dashboard() {
  const { data: customers = [], isLoading } = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list("-created_date", 500),
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const totalLeads = customers.length;
  const activeDeals = customers.filter(
    (c) => !["completed", "service"].includes(c.stage)
  ).length;
  const closedDeals = customers.filter(
    (c) => ["deal_closed", "installing", "completed"].includes(c.stage)
  ).length;
  const totalRevenue = customers
    .filter((c) => ["deal_closed", "installing", "completed"].includes(c.stage))
    .reduce((sum, c) => sum + (c.deal_amount || 0), 0);
  const installing = customers.filter((c) => c.stage === "installing").length;
  const needsFollowup = customers.filter(
    (c) => c.next_followup && new Date(c.next_followup) <= new Date()
  ).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">דשבורד</h1>
        <p className="text-muted-foreground text-sm">סקירה כללית של העסק</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard title="סה״כ לידים" value={totalLeads} icon={Users} color="bg-blue-500" />
        <StatCard title="עסקאות פעילות" value={activeDeals} icon={TrendingUp} color="bg-purple-500" />
        <StatCard title="עסקאות שנסגרו" value={closedDeals} icon={CheckCircle2} color="bg-emerald-500" />
        <StatCard
          title="הכנסות"
          value={`₪${totalRevenue.toLocaleString()}`}
          icon={DollarSign}
          color="bg-amber-500"
        />
        <StatCard title="בהתקנה" value={installing} icon={Wrench} color="bg-teal-500" />
        <StatCard title="דורש מעקב" value={needsFollowup} icon={AlertTriangle} color="bg-red-500" />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <StageChart customers={customers} />
        <RecentCustomers customers={customers} />
      </div>
    </div>
  );
}