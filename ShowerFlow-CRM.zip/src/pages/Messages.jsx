import { Card, CardContent } from "@/components/ui/card";
import { MessageSquare, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Messages() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">הודעות</h1>
        <p className="text-muted-foreground text-sm">ניהול הודעות WhatsApp</p>
      </div>
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-16 h-16 rounded-2xl bg-green-50 flex items-center justify-center mb-4">
            <MessageSquare className="w-8 h-8 text-green-500" />
          </div>
          <h2 className="text-lg font-semibold mb-2">חיבור WhatsApp Business API</h2>
          <p className="text-muted-foreground text-sm max-w-md mb-6">
            כדי לקבל ולשלוח הודעות WhatsApp ישירות מהמערכת, יש לחבר את חשבון WhatsApp Business API.
            <br />
            צור קשר איתנו להגדרת החיבור.
          </p>
          <Button className="gap-2 bg-green-600 hover:bg-green-700">
            <MessageSquare className="w-4 h-4" />
            הגדר חיבור WhatsApp
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}