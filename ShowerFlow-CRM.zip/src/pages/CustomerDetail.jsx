import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2 } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import CustomerHeader from "@/components/customer-detail/CustomerHeader";
import CustomerInfo from "@/components/customer-detail/CustomerInfo";
import ActivityTimeline from "@/components/customer-detail/ActivityTimeline";
import AddActivityForm from "@/components/customer-detail/AddActivityForm";
import EditCustomerDialog from "@/components/customer-detail/EditCustomerDialog";
import CustomerPhotos from "@/components/customer-detail/CustomerPhotos";

export default function CustomerDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const customerId = window.location.pathname.split("/").pop();
  const navigate = useNavigate();
  const [editOpen, setEditOpen] = useState(false);

  const { data: customer, isLoading } = useQuery({
    queryKey: ["customer", customerId],
    queryFn: async () => {
      const all = await base44.entities.Customer.list();
      return all.find((c) => c.id === customerId);
    },
    enabled: !!customerId,
  });

  const { data: activities = [] } = useQuery({
    queryKey: ["activities", customerId],
    queryFn: () => base44.entities.Activity.filter({ customer_id: customerId }, "-created_date", 100),
    enabled: !!customerId,
  });

  const handleDelete = async () => {
    if (confirm("למחוק את הלקוח?")) {
      await base44.entities.Customer.delete(customerId);
      navigate("/customers");
    }
  };

  if (isLoading || !customer) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <CustomerHeader customer={customer} />

      <div className="flex gap-2">
        <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setEditOpen(true)}>
          <Pencil className="w-3.5 h-3.5" />
          ערוך
        </Button>
        <Button variant="outline" size="sm" className="gap-1.5 text-destructive hover:text-destructive" onClick={handleDelete}>
          <Trash2 className="w-3.5 h-3.5" />
          מחק
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
          <CustomerInfo customer={customer} />
          <CustomerPhotos customer={customer} />
        </div>
        <div className="lg:col-span-2 space-y-4">
          <AddActivityForm customerId={customerId} />
          <ActivityTimeline activities={activities} />
        </div>
      </div>

      <EditCustomerDialog customer={customer} open={editOpen} onClose={() => setEditOpen(false)} />
    </div>
  );
}