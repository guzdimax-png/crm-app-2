import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { UserPlus, Mail, Shield, User, Trash2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [email, setEmail] = useState("");
  const [inviting, setInviting] = useState(false);

  const { data: currentUser } = useQuery({
    queryKey: ["me"],
    queryFn: () => base44.auth.me(),
  });

  const { data: users = [] } = useQuery({
    queryKey: ["users"],
    queryFn: () => base44.entities.User.list(),
    enabled: currentUser?.role === "admin",
  });

  const handleInvite = async () => {
    if (!email.trim()) return;
    setInviting(true);
    try {
      await base44.users.inviteUser(email.trim(), "user");
      toast({ title: "הזמנה נשלחה!", description: `נשלח מייל הזמנה ל-${email}` });
      setEmail("");
      queryClient.invalidateQueries({ queryKey: ["users"] });
    } catch (e) {
      toast({ title: "שגיאה", description: "לא ניתן לשלוח הזמנה", variant: "destructive" });
    }
    setInviting(false);
  };

  const isAdmin = currentUser?.role === "admin";

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold">הגדרות</h1>
        <p className="text-muted-foreground text-sm">ניהול משתמשים והרשאות</p>
      </div>

      {/* My Profile */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <User className="w-4 h-4" />
            הפרופיל שלי
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-lg">
              {currentUser?.full_name?.[0] || "?"}
            </div>
            <div>
              <p className="font-semibold">{currentUser?.full_name || "—"}</p>
              <p className="text-sm text-muted-foreground">{currentUser?.email}</p>
            </div>
            <Badge className="mr-auto" variant={isAdmin ? "default" : "secondary"}>
              {isAdmin ? "מנהל" : "משתמש"}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Invite User */}
      {isAdmin && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <UserPlus className="w-4 h-4" />
              הזמן משתמש חדש
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              המשתמש יקבל מייל עם קישור להגדרת סיסמה אישית.
            </p>
            <div className="flex gap-2">
              <div className="flex-1 space-y-1.5">
                <Label>כתובת אימייל</Label>
                <Input
                  type="email"
                  dir="ltr"
                  placeholder="partner@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleInvite()}
                />
              </div>
              <div className="flex items-end">
                <Button onClick={handleInvite} disabled={inviting || !email.trim()} className="gap-2">
                  <Mail className="w-4 h-4" />
                  {inviting ? "שולח..." : "שלח הזמנה"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Users List */}
      {isAdmin && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Shield className="w-4 h-4" />
              משתמשים במערכת
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {users.map((u) => (
                <div key={u.id} className="flex items-center gap-4 px-5 py-3">
                  <div className="w-9 h-9 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm shrink-0">
                    {u.full_name?.[0] || u.email?.[0]?.toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm">{u.full_name || "—"}</p>
                    <p className="text-xs text-muted-foreground" dir="ltr">{u.email}</p>
                  </div>
                  <Badge variant={u.role === "admin" ? "default" : "secondary"}>
                    {u.role === "admin" ? "מנהל" : "משתמש"}
                  </Badge>
                </div>
              ))}
              {users.length === 0 && (
                <p className="text-center text-muted-foreground text-sm py-8">אין משתמשים</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {!isAdmin && (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground text-sm">
            רק מנהל יכול לנהל משתמשים
          </CardContent>
        </Card>
      )}
    </div>
  );
}