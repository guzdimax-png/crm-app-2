import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Phone, MessageCircle, ArrowRight, MapPin } from "lucide-react";
import { STAGE_MAP, PRIORITY_LABELS, PRIORITY_COLORS } from "@/lib/stageConfig";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

export default function CustomerHeader({ customer }) {
  const stage = STAGE_MAP[customer.stage];

  return (
    <div className="space-y-4">
      <Link
        to="/customers"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowRight className="w-4 h-4" />
        חזרה לרשימה
      </Link>

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center font-bold text-xl">
            {customer.full_name?.[0]}
          </div>
          <div>
            <h1 className="text-2xl font-bold">{customer.full_name}</h1>
            <div className="flex items-center gap-3 text-sm text-muted-foreground mt-0.5">
              <span dir="ltr">{customer.phone}</span>
              {customer.city && (
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {customer.city}
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={cn(stage?.color, "text-white")}>{stage?.label}</Badge>
          {customer.priority && customer.priority !== "medium" && (
            <Badge variant="outline" className={PRIORITY_COLORS[customer.priority]}>
              {PRIORITY_LABELS[customer.priority]}
            </Badge>
          )}
          <a href={`tel:${customer.phone}`}>
            <Button size="icon" variant="outline" className="text-emerald-600">
              <Phone className="w-4 h-4" />
            </Button>
          </a>
          <a
            href={`https://wa.me/${customer.phone?.replace(/[^0-9]/g, "")}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button size="icon" variant="outline" className="text-green-600">
              <MessageCircle className="w-4 h-4" />
            </Button>
          </a>
        </div>
      </div>
    </div>
  );
}