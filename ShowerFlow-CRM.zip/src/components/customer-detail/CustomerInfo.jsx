import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { SOURCE_LABELS } from "@/lib/stageConfig";

function InfoRow({ label, value }) {
  if (!value) return null;
  return (
    <div className="flex justify-between py-2 border-b border-border last:border-0">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className="text-sm font-medium text-left" dir="auto">{value}</span>
    </div>
  );
}

export default function CustomerInfo({ customer }) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">פרטי לקוח</CardTitle>
      </CardHeader>
      <CardContent className="space-y-0">
        <InfoRow label="כתובת" value={customer.address} />
        <InfoRow label="עיר" value={customer.city} />
        <InfoRow label="מקור" value={SOURCE_LABELS[customer.source]} />
        <InfoRow label="סוג מקלחון" value={customer.shower_type} />
        <InfoRow label="מידות" value={customer.measurements} />
        <InfoRow label="צבע זכוכית" value={customer.glass_color} />
        <InfoRow label="פרזול" value={customer.hardware_color} />
        <InfoRow
          label="מחיר עסקה"
          value={customer.deal_amount ? `₪${customer.deal_amount.toLocaleString()}` : null}
        />
        <InfoRow
          label="פגישה"
          value={customer.meeting_date ? format(new Date(customer.meeting_date), "dd/MM/yy HH:mm") : null}
        />
        <InfoRow
          label="התקנה"
          value={customer.installation_date ? format(new Date(customer.installation_date), "dd/MM/yy HH:mm") : null}
        />
        <InfoRow
          label="מעקב הבא"
          value={customer.next_followup ? format(new Date(customer.next_followup), "dd/MM/yy HH:mm") : null}
        />
        {customer.notes && (
          <div className="pt-3">
            <p className="text-sm text-muted-foreground mb-1">הערות</p>
            <p className="text-sm whitespace-pre-wrap">{customer.notes}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}