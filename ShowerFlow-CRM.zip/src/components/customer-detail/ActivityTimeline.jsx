import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { STAGE_MAP } from "@/lib/stageConfig";
import {
  MessageCircle,
  Phone,
  Calendar,
  FileText,
  Camera,
  ArrowLeftRight,
  StickyNote,
  Wrench,
} from "lucide-react";
import { cn } from "@/lib/utils";

const TYPE_CONFIG = {
  whatsapp_in: { icon: MessageCircle, label: "הודעה נכנסת", color: "bg-green-500" },
  whatsapp_out: { icon: MessageCircle, label: "הודעה יוצאת", color: "bg-blue-500" },
  call_in: { icon: Phone, label: "שיחה נכנסת", color: "bg-emerald-500" },
  call_out: { icon: Phone, label: "שיחה יוצאת", color: "bg-cyan-500" },
  meeting: { icon: Calendar, label: "פגישה", color: "bg-purple-500" },
  note: { icon: StickyNote, label: "הערה", color: "bg-amber-500" },
  stage_change: { icon: ArrowLeftRight, label: "שינוי שלב", color: "bg-indigo-500" },
  photo: { icon: Camera, label: "תמונה", color: "bg-pink-500" },
  document: { icon: FileText, label: "מסמך", color: "bg-orange-500" },
  installation: { icon: Wrench, label: "התקנה", color: "bg-teal-500" },
};

export default function ActivityTimeline({ activities }) {
  if (!activities?.length) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">היסטוריה</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground text-sm py-8">אין פעילויות עדיין</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">היסטוריה</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => {
            const config = TYPE_CONFIG[activity.type] || TYPE_CONFIG.note;
            const Icon = config.icon;
            return (
              <div key={activity.id} className="flex gap-3">
                <div className={cn("w-8 h-8 rounded-full flex items-center justify-center shrink-0", config.color)}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">{config.label}</p>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(activity.created_date), "dd/MM HH:mm")}
                    </span>
                  </div>
                  {activity.type === "stage_change" ? (
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {STAGE_MAP[activity.old_stage]?.label || activity.old_stage} ← {STAGE_MAP[activity.new_stage]?.label || activity.new_stage}
                    </p>
                  ) : activity.content ? (
                    <p className="text-sm text-muted-foreground mt-0.5 whitespace-pre-wrap">{activity.content}</p>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}