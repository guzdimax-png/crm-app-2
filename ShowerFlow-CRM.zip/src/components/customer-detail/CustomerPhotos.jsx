import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, X, ImageIcon } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";

export default function CustomerPhotos({ customer }) {
  const queryClient = useQueryClient();
  const [uploading, setUploading] = useState(false);
  const photos = customer.photos || [];

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    const updatedPhotos = [...photos, file_url];
    await base44.entities.Customer.update(customer.id, { photos: updatedPhotos });
    queryClient.invalidateQueries({ queryKey: ["customer", customer.id] });
    setUploading(false);
  };

  const handleRemove = async (index) => {
    const updatedPhotos = photos.filter((_, i) => i !== index);
    await base44.entities.Customer.update(customer.id, { photos: updatedPhotos });
    queryClient.invalidateQueries({ queryKey: ["customer", customer.id] });
  };

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-base">תמונות</CardTitle>
        <label>
          <input type="file" accept="image/*" className="hidden" onChange={handleUpload} />
          <Button size="sm" variant="outline" className="gap-1.5" asChild disabled={uploading}>
            <span>
              <Upload className="w-3.5 h-3.5" />
              {uploading ? "מעלה..." : "העלאה"}
            </span>
          </Button>
        </label>
      </CardHeader>
      <CardContent>
        {photos.length > 0 ? (
          <div className="grid grid-cols-3 gap-2">
            {photos.map((url, idx) => (
              <div key={idx} className="relative group aspect-square rounded-lg overflow-hidden bg-secondary">
                <img src={url} alt="" className="w-full h-full object-cover" />
                <button
                  onClick={() => handleRemove(idx)}
                  className="absolute top-1 left-1 w-6 h-6 bg-black/60 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center py-6 text-muted-foreground">
            <ImageIcon className="w-8 h-8 opacity-30 mb-2" />
            <p className="text-sm">אין תמונות</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}