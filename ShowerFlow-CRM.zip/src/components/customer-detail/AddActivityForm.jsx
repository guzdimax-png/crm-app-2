import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Send } from "lucide-react";

export default function AddActivityForm({ customerId }) {
  const queryClient = useQueryClient();
  const [type, setType] = useState("note");
  const [content, setContent] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!content.trim()) return;
    setSaving(true);
    await base44.entities.Activity.create({
      customer_id: customerId,
      type,
      content: content.trim(),
    });
    queryClient.invalidateQueries({ queryKey: ["activities", customerId] });
    setContent("");
    setSaving(false);
  };

  return (
    <div className="flex gap-2 items-end">
      <Select value={type} onValueChange={setType}>
        <SelectTrigger className="w-32 shrink-0">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="note">הערה</SelectItem>
          <SelectItem value="call_out">שיחה יוצאת</SelectItem>
          <SelectItem value="call_in">שיחה נכנסת</SelectItem>
          <SelectItem value="whatsapp_out">WhatsApp יוצא</SelectItem>
          <SelectItem value="whatsapp_in">WhatsApp נכנס</SelectItem>
          <SelectItem value="meeting">פגישה</SelectItem>
        </SelectContent>
      </Select>
      <Textarea
        placeholder="הוסף פעילות..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        rows={1}
        className="flex-1"
      />
      <Button size="icon" onClick={handleSubmit} disabled={saving || !content.trim()}>
        <Send className="w-4 h-4" />
      </Button>
    </div>
  );
}