import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { STAGES } from "@/lib/stageConfig";

export default function EditCustomerDialog({ customer, open, onClose }) {
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ ...customer });

  const update = (field, value) => setForm((p) => ({ ...p, [field]: value }));

  const handleSave = async () => {
    setSaving(true);
    const { id, created_date, updated_date, created_by, ...data } = form;
    await base44.entities.Customer.update(customer.id, data);
    queryClient.invalidateQueries({ queryKey: ["customer", customer.id] });
    queryClient.invalidateQueries({ queryKey: ["customers"] });
    setSaving(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>עריכת לקוח</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>שם מלא</Label>
              <Input value={form.full_name || ""} onChange={(e) => update("full_name", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>טלפון</Label>
              <Input dir="ltr" value={form.phone || ""} onChange={(e) => update("phone", e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>כתובת</Label>
              <Input value={form.address || ""} onChange={(e) => update("address", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>עיר</Label>
              <Input value={form.city || ""} onChange={(e) => update("city", e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>שלב</Label>
              <Select value={form.stage || "new_lead"} onValueChange={(v) => update("stage", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {STAGES.map((s) => (
                    <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>עדיפות</Label>
              <Select value={form.priority || "medium"} onValueChange={(v) => update("priority", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">נמוכה</SelectItem>
                  <SelectItem value="medium">בינונית</SelectItem>
                  <SelectItem value="high">גבוהה</SelectItem>
                  <SelectItem value="urgent">דחוף</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>סוג מקלחון</Label>
              <Select value={form.shower_type || ""} onValueChange={(v) => update("shower_type", v)}>
                <SelectTrigger><SelectValue placeholder="בחר" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="חזיתי">חזיתי</SelectItem>
                  <SelectItem value="פינתי">פינתי</SelectItem>
                  <SelectItem value="חצי עיגול">חצי עיגול</SelectItem>
                  <SelectItem value="אמבטיון">אמבטיון</SelectItem>
                  <SelectItem value="מקלחון הזזה">מקלחון הזזה</SelectItem>
                  <SelectItem value="מקלחון קבוע">מקלחון קבוע</SelectItem>
                  <SelectItem value="אחר">אחר</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>צבע פרזול</Label>
              <Select value={form.hardware_color || ""} onValueChange={(v) => update("hardware_color", v)}>
                <SelectTrigger><SelectValue placeholder="בחר" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="כרום">כרום</SelectItem>
                  <SelectItem value="זהב">זהב</SelectItem>
                  <SelectItem value="שחור">שחור</SelectItem>
                  <SelectItem value="ניקל">ניקל</SelectItem>
                  <SelectItem value="ברונזה">ברונזה</SelectItem>
                  <SelectItem value="אחר">אחר</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>מידות</Label>
              <Input value={form.measurements || ""} onChange={(e) => update("measurements", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>צבע זכוכית</Label>
              <Input value={form.glass_color || ""} onChange={(e) => update("glass_color", e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>מחיר עסקה</Label>
              <Input type="number" value={form.deal_amount || ""} onChange={(e) => update("deal_amount", Number(e.target.value))} />
            </div>
            <div className="space-y-1.5">
              <Label>מקור</Label>
              <Select value={form.source || ""} onValueChange={(v) => update("source", v)}>
                <SelectTrigger><SelectValue placeholder="בחר" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="phone">טלפון</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                  <SelectItem value="website">אתר</SelectItem>
                  <SelectItem value="referral">הפניה</SelectItem>
                  <SelectItem value="facebook">פייסבוק</SelectItem>
                  <SelectItem value="instagram">אינסטגרם</SelectItem>
                  <SelectItem value="other">אחר</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>תאריך פגישה</Label>
              <Input type="datetime-local" value={form.meeting_date || ""} onChange={(e) => update("meeting_date", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>תאריך התקנה</Label>
              <Input type="datetime-local" value={form.installation_date || ""} onChange={(e) => update("installation_date", e.target.value)} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>תאריך מעקב הבא</Label>
            <Input type="datetime-local" value={form.next_followup || ""} onChange={(e) => update("next_followup", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>הערות</Label>
            <Textarea value={form.notes || ""} onChange={(e) => update("notes", e.target.value)} rows={3} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>ביטול</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? "שומר..." : "שמור"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}