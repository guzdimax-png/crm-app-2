import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Phone } from "lucide-react";
import { STAGE_MAP, PRIORITY_COLORS, PRIORITY_LABELS } from "@/lib/stageConfig";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function CustomerRow({ customer }) {
  const stage = STAGE_MAP[customer.stage];

  return (
    <Link
      to={`/customers/${customer.id}`}
      className="flex items-center gap-4 p-4 hover:bg-secondary/50 transition-colors border-b border-border last:border-0"
    >
      <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm shrink-0">
        {customer.full_name?.[0]}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{customer.full_name}</p>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span dir="ltr">{customer.phone}</span>
          {customer.city && <span>• {customer.city}</span>}
        </div>
      </div>
      <div className="hidden sm:flex items-center gap-2">
        {customer.priority && customer.priority !== "medium" && (
          <Badge variant="outline" className={cn("text-xs", PRIORITY_COLORS[customer.priority])}>
            {PRIORITY_LABELS[customer.priority]}
          </Badge>
        )}
        <Badge variant="secondary" className="text-xs">
          {stage?.label}
        </Badge>
      </div>
      <span className="text-xs text-muted-foreground hidden md:block">
        {format(new Date(customer.created_date), "dd/MM/yy")}
      </span>
      <a
        href={`tel:${customer.phone}`}
        onClick={(e) => e.stopPropagation()}
        className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-600 flex items-center justify-center hover:bg-emerald-500/20 transition-colors shrink-0"
      >
        <Phone className="w-4 h-4" />
      </a>
    </Link>
  );
}