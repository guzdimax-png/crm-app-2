import { Card } from "@/components/ui/card";
import { Phone, Calendar, DollarSign } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import { PRIORITY_COLORS } from "@/lib/stageConfig";

export default function PipelineCard({ customer, isDragging }) {
  return (
    <Link to={`/customers/${customer.id}`}>
      <Card
        className={cn(
          "p-3 cursor-pointer hover:shadow-md transition-all border",
          isDragging && "shadow-xl ring-2 ring-primary/30 rotate-1"
        )}
      >
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs shrink-0">
              {customer.full_name?.[0]}
            </div>
            <p className="font-medium text-sm truncate">{customer.full_name}</p>
          </div>
          {customer.priority && customer.priority !== "medium" && (
            <span className={cn("text-xs font-bold", PRIORITY_COLORS[customer.priority])}>
              ●
            </span>
          )}
        </div>
        <div className="space-y-1 text-xs text-muted-foreground">
          {customer.phone && (
            <div className="flex items-center gap-1.5">
              <Phone className="w-3 h-3" />
              <span dir="ltr">{customer.phone}</span>
            </div>
          )}
          {customer.meeting_date && (
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3 h-3" />
              <span>{format(new Date(customer.meeting_date), "dd/MM/yy")}</span>
            </div>
          )}
          {customer.deal_amount > 0 && (
            <div className="flex items-center gap-1.5">
              <DollarSign className="w-3 h-3" />
              <span>₪{customer.deal_amount.toLocaleString()}</span>
            </div>
          )}
        </div>
      </Card>
    </Link>
  );
}