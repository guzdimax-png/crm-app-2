import { Droppable, Draggable } from "@hello-pangea/dnd";
import { cn } from "@/lib/utils";
import PipelineCard from "./PipelineCard";

export default function PipelineColumn({ stage, customers, index }) {
  return (
    <div className="flex flex-col w-72 shrink-0 bg-secondary/50 rounded-xl">
      <div className="p-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={cn("w-3 h-3 rounded-full", stage.color)} />
          <span className="font-semibold text-sm">{stage.label}</span>
        </div>
        <span className="text-xs text-muted-foreground bg-background px-2 py-0.5 rounded-full font-medium">
          {customers.length}
        </span>
      </div>
      <Droppable droppableId={stage.id}>
        {(provided, snapshot) => (
          <div
            ref={provided.innerRef}
            {...provided.droppableProps}
            className={cn(
              "flex-1 p-2 space-y-2 min-h-[200px] overflow-y-auto transition-colors rounded-b-xl",
              snapshot.isDraggingOver && "bg-primary/5"
            )}
          >
            {customers.map((customer, idx) => (
              <Draggable key={customer.id} draggableId={customer.id} index={idx}>
                {(provided, snapshot) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.draggableProps}
                    {...provided.dragHandleProps}
                  >
                    <PipelineCard customer={customer} isDragging={snapshot.isDragging} />
                  </div>
                )}
              </Draggable>
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </div>
  );
}