import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { STAGE_MAP } from "@/lib/stageConfig";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function RecentCustomers({ customers }) {
  const recent = [...customers]
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
    .slice(0, 6);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-semibold">לידים אחרונים</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-border">
          {recent.map((c) => {
            const stage = STAGE_MAP[c.stage];
            return (
              <Link
                key={c.id}
                to={`/customers/${c.id}`}
                className="flex items-center justify-between px-5 py-3 hover:bg-secondary/50 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm shrink-0">
                    {c.full_name?.[0]}
                  </div>
                  <div className="min-w-0">
                    <p className="font-medium text-sm truncate">{c.full_name}</p>
                    <p className="text-xs text-muted-foreground">{c.phone}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Badge variant="secondary" className={cn("text-xs", stage?.color?.replace("bg-", "text-"))}>
                    {stage?.label}
                  </Badge>
                  <span className="text-xs text-muted-foreground hidden sm:block">
                    {format(new Date(c.created_date), "dd/MM")}
                  </span>
                </div>
              </Link>
            );
          })}
          {recent.length === 0 && (
            <p className="text-center text-muted-foreground text-sm py-8">אין לקוחות עדיין</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}